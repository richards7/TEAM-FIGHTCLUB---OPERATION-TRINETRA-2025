from Crypto.Cipher import AES, PKCS1_OAEP
from Crypto.PublicKey import RSA
from Crypto.Random import get_random_bytes

def generate_rsa_keys():
    key = RSA.generate(2048)
    private_key = key.export_key()
    public_key = key.publickey().export_key()
    return private_key, public_key

def encrypt_message(message, public_key):
    pub_key = RSA.import_key(public_key)
    
    aes_key = get_random_bytes(32)

    cipher_aes = AES.new(aes_key, AES.MODE_EAX)
    ciphertext, tag = cipher_aes.encrypt_and_digest(message.encode())
    
    cipher_rsa = PKCS1_OAEP.new(pub_key)
    enc_aes_key = cipher_rsa.encrypt(aes_key)
    
    return (enc_aes_key, ciphertext, tag, cipher_aes.nonce)

def decrypt_message(enc_package, private_key):
    enc_aes_key, ciphertext, tag, nonce = enc_package
    
    priv_key = RSA.import_key(private_key)
    
    cipher_rsa = PKCS1_OAEP.new(priv_key)
    aes_key = cipher_rsa.decrypt(enc_aes_key)
    
    cipher_aes = AES.new(aes_key, AES.MODE_EAX, nonce)
    plaintext = cipher_aes.decrypt_and_verify(ciphertext, tag)
    
    return plaintext.decode()

if __name__ == "__main__":
    private_key, public_key = generate_rsa_keys()
    
    user_message = input("Enter a secret message: ")
    
    package = encrypt_message(user_message, public_key)
    print("\n[+] Encrypted Package (looks random):")
    print(package)
    
    decrypted_message = decrypt_message(package, private_key)
    print("\n[+] Final Decrypted Message:", decrypted_message)
