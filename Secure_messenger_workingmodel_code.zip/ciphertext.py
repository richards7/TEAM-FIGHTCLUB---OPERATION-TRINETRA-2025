from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes

key = get_random_bytes(32)
print("AES Key (secret):", key)

cipher = AES.new(key, AES.MODE_EAX)

message = "Defense Hackathon 2025"
ciphertext, tag = cipher.encrypt_and_digest(message.encode())

print("\nOriginal Message:", message)
print("Ciphertext (encrypted data):", ciphertext)
print("Nonce (random number):", cipher.nonce)
print("Tag (used for integrity):", tag)

cipher_dec = AES.new(key, AES.MODE_EAX, nonce=cipher.nonce)
decrypted_message = cipher_dec.decrypt_and_verify(ciphertext, tag)

print("\nDecrypted Message:", decrypted_message.decode())
