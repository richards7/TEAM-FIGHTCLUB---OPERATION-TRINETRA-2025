from Crypto.Hash import SHA256

message = "Defense Hackathon 2025"
print("Original Message:", message)

hash_object = SHA256.new(message.encode())
original_hash = hash_object.hexdigest()
print("Original SHA-256 Hash:", original_hash)

received_message = "Defense Hackathon 2025"
received_hash = SHA256.new(received_message.encode()).hexdigest()

if original_hash == received_hash:
    print("\n[+] Integrity Check Passed – Message not changed")
else:
    print("\n[!] Integrity Check Failed – Message was modified!")

tampered_message = "Defense Hackathon 2026"
tampered_hash = SHA256.new(tampered_message.encode()).hexdigest()

if original_hash == tampered_hash:
    print("[+] Integrity Check Passed – Message not changed")
else:
    print("[!] Integrity Check Failed – Message was modified!")
