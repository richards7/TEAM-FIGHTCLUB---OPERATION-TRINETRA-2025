from Crypto.Cipher import AES, PKCS1_OAEP
from Crypto.PublicKey import RSA
from Crypto.Hash import SHA256
from Crypto.Random import get_random_bytes

def generate_rsa_keys():
    key = RSA.generate(2048)
    private_key = key.export_key()
    public_key = key.publickey().export_key()

    with open("private_key.pem", "wb") as f:
        f.write(private_key)
    with open("public_key.pem", "wb") as f:
        f.write(public_key)

    print("[+] RSA Keys generated: private_key.pem & public_key.pem")

def encrypt_message(message):
    public_key = RSA.import_key(open("public_key.pem").read())
    
    aes_key = get_random_bytes(32)
    
    cipher_aes = AES.new(aes_key, AES.MODE_GCM)
    ciphertext, tag = cipher_aes.encrypt_and_digest(message.encode())
    
    cipher_rsa = PKCS1_OAEP.new(public_key)
    enc_aes_key = cipher_rsa.encrypt(aes_key)
    
    h = SHA256.new(ciphertext)
    
    package = {
        "enc_aes_key": enc_aes_key,
        "ciphertext": ciphertext,
        "tag": tag,
        "nonce": cipher_aes.nonce,
        "hash": h.digest()
    }
    
    print("[+] Message encrypted and packaged.")
    return package

def decrypt_message(package):
    private_key = RSA.import_key(open("private_key.pem").read())
    
    cipher_rsa = PKCS1_OAEP.new(private_key)
    aes_key = cipher_rsa.decrypt(package["enc_aes_key"])

    cipher_aes = AES.new(aes_key, AES.MODE_GCM, nonce=package["nonce"])
    plaintext = cipher_aes.decrypt_and_verify(package["ciphertext"], package["tag"])

    h = SHA256.new(package["ciphertext"])
    if h.digest() == package["hash"]:
        print("[+] Integrity check passed (SHA-256).")
    else:
        print("[!] Integrity check failed.")
    
    return plaintext.decode()

if __name__ == "__main__":
    generate_rsa_keys()
    pkg = encrypt_message("Mission: Secure base at 0500 hours")
    msg = decrypt_message(pkg)
    print("[+] Final Decrypted Message:", msg)


